var map;
var tbl = '1bKyeb4tf3K8wHIxMfyno3CI3VbeMKiPcW882oYo';
var api = 'AIzaSyDwXl3a4gf2cuWKRKLNYkYT9GkDAUlGE9U';
var img = '/images/';
var styles = [
	{"featureType": "water","elementType": "geometry","stylers": [{ "saturation": -100 },{ "lightness": -27 }]},
	{"featureType": "road","elementType": "geometry","stylers": [{ "saturation": -51 }]},
	{"featureType": "landscape.natural","stylers": [{ "saturation": -76 }]},
	{"featureType": "poi","stylers": [{ "visibility": "simplified" },{ "saturation": -71 }]},
	{"featureType": "poi"  }
	];			
var markerArray = [];
var icon = new Object();
	icon.today = '/images/light-green-dot.png';
	icon.tomorrow = '/images/blue-dot.png';
	icon.upcoming = '/images/yellow-dot.png';
	icon.previous = '/images/white-dot.png';
	icon.instore = '/images/red-dot.png';
	icon.me = '/images/person-icon.png';
var infowindow;	
var d1 = new Date();
var dCenter = new google.maps.LatLng(38.91133417922352, 282.9677991333008);
var dZoom = 13;
d1.setHours(0);		
d1.setMinutes(0);
d1.setSeconds(0);
var d2 = new Date();		
var today = $.datepicker.formatDate('m/d/y', d1);
d2.setDate(d2.getDate()+1);
var tomorrow = $.datepicker.formatDate('m/d/y', d2);
var mybounds = new google.maps.LatLngBounds();
var geocoder = new google.maps.Geocoder();
google.maps.event.addDomListener(window, 'load', initialize);


var mCount = new Object();
	mCount.today = 0;
	mCount.tomorrow = 0;
	mCount.upcoming = 0;
	mCount.previous = 0;
	mCount.instore = 0;

//FUNCTIONS
function initialize() {
	var mapOptions = {
		zoom: dZoom,
		center: dCenter,
		disableDefaultUI: true,
		mapTypeControlOptions: {
		  mapTypeIds: [google.maps.MapTypeId.ROADMAP, 'map_style']
		},
		maxZoom: 16,
		minZoom: 6
	};				
	var styledMap = new google.maps.StyledMapType(styles, {name: "Styled Map"});
	map = new google.maps.Map(document.getElementById('map-canvas'), mapOptions);
	map.mapTypes.set('map_style', styledMap);
	map.setMapTypeId('map_style');
	var legend = document.getElementById('legend');
	var navigation = document.getElementById('navigation');
	map.controls[google.maps.ControlPosition.TOP_RIGHT].push(legend);	
	map.controls[google.maps.ControlPosition.TOP_LEFT].push(navigation);
	getFusionData();
	showMe();
	dCenter = map.getCenter();
	google.maps.event.addListener(map,'zoom_changed', function () {
		dCenter = map.getCenter();
		dZoom = map.getZoom();
	});
	google.maps.event.addListener(map,'dragend', function () {
		dCenter = map.getCenter();
		dZoom = map.getZoom();				
	});
}

function showMe(){
	var options = {
    	timeout: 500000, enableHighAccuracy: true
	};
	var myUpdatedPos = navigator.geolocation.getCurrentPosition(onSuccess, onError, options);

	function onSuccess(position) {
		var me_marker = new google.maps.Marker();
			me_marker.setIcon(icon.me);
			me_marker.setPosition(new google.maps.LatLng(position.coords.latitude, position.coords.longitude));
			me_marker.setMap(map);		
		google.maps.event.addListener(me_marker, 'click', function () {
			closeAllInfo();	
		
			var txt="<table border='0' cellpadding='3' cellspacing='0' style='width: 150px;'>";
				txt = txt + "<tr>";
				txt = txt + "<td valign='top'><img src='/images/milky.png' height='40'></td>";			
				txt = txt + "<td valign='middle' align='center'><strong>THIS IS YOU!</strong></td>";
				txt = txt + "</tr>";
				txt = txt + "</table>";
							
			infowindow = new google.maps.InfoWindow({content: txt, disableAutoPan: false});
			infowindow.open(map, me_marker);
			map.panTo(me_marker.getPosition());	
			google.maps.event.addListener(infowindow, 'closeclick', function () {
				map.panTo(dCenter);	
				map.setZoom(dZoom);
			});		                                                                 
		});	

	}
    function onError(error) {
        //console.log('code: '    + error.code    + '\n' + 'message: ' + error.message + '\n');
    }
}

function getFusionData(){	
	var qry = "select * from " + tbl;				
	var script = document.createElement('script');
	var url = ['https://www.googleapis.com/fusiontables/v1/query?'];
	url.push('sql=');
	var encodedQuery = encodeURIComponent(qry);
	url.push(encodedQuery);
	url.push('&callback=drawMap');
	url.push('&key=' + api);
	script.src = url.join('');
	var body = document.getElementsByTagName('body')[0];
	body.appendChild(script);
}

google.maps.Marker.prototype.marker_type = {
    get value(){
        return this._value;
    },

    set value(val){
        this._value = val;
    }
};
google.maps.Marker.prototype.marker_date = {
    get value(){
        return this._value;
    },
    set value(val){
        this._value = val;
    }
};
function drawMap(data){				
	var rows = data['rows'];
	for (var i in rows) {
		isDisplay = rows[i][8];	
		
		if(isDisplay == 'yes'){
			LatLng = new google.maps.LatLng(rows[i][5],rows[i][6]);
			mybounds.extend(LatLng);
			markerArray[i] = new google.maps.Marker({position:LatLng , map: map});	
			markerArray[i].setAnimation(google.maps.Animation.DROP);
			markerArray[i].marker_date = new Date(rows[i][3]);
			markerArray[i].marker_date.setYear(d1.getYear()+1900) ;		
			markerArray[i].marker_loc = rows[i][0];
			markerArray[i].marker_link = rows[i][1];
			markerArray[i].marker_address = rows[i][2];
			markerArray[i].marker_times = rows[i][4];		
			markerArray[i].marker_isStore = rows[i][7];		

			if(markerArray[i].marker_isStore == 'yes'){
				markerArray[i].setIcon(icon.instore);
				markerArray[i].marker_type = 'in store';
				mCount.instore++;
			} else {
				thisDate = $.datepicker.formatDate('m/d/y', markerArray[i].marker_date);
				switch(thisDate){
					case today:
						markerArray[i].setIcon(icon.today);
						markerArray[i].marker_type = 'today';
						mCount.today++;
						break;
					case tomorrow:
						markerArray[i].setIcon(icon.tomorrow);
						markerArray[i].marker_type = 'tomorrow'; 
						mCount.tomorrow++;
						break;
					default:
						if(d1 < markerArray[i].marker_date){
							markerArray[i].setIcon(icon.upcoming);
							markerArray[i].marker_type = 'upcoming'; 
							mCount.upcoming++;
						} else {
							markerArray[i].setIcon(icon.previous);
							markerArray[i].marker_type = 'previous';
							mCount.previous++;
						}
				}
			}


			addListener(markerArray[i])
		}
	}
	map.fitBounds(mybounds);
	dCenter = map.getCenter();
	$('#cnt_today').text('('+mCount.today+')');
	$('#cnt_tomorrow').text('('+mCount.tomorrow+')');
	$('#cnt_upcoming').text('('+mCount.upcoming+')');
	$('#cnt_previous').text('('+mCount.previous+')');
	$('#cnt_instore').text('('+mCount.instore+')');
	$('#cnt_all').text('('+markerArray.length+')');
}	
function addListener(marker){
	google.maps.event.addListener(marker, 'click', function () {
		var txt="<table border='0' cellpadding='3' cellspacing='0' style='width: 250px;'>";
			txt = txt + "<tr>";
			txt = txt + "<td valign='top' width='35'><img src='/images/milky.png' height='40'></td>";
			
			txt = txt + "<td valign='top'><strong>" + marker.marker_loc + "</strong><br>";
			if(marker.marker_link.length != 0){
				txt = txt + "<a href='" + marker.marker_link + "' target='_blank' class='mapLink'>" + marker.marker_link + "</a><br>";
			}
			txt = txt + marker.marker_address + "<br>";
			if(marker.marker_isStore == 'yes'){
				txt = txt + "In Store Location</td>";
			} else {
				txt = txt + $.datepicker.formatDate('m/d/y', marker.marker_date);
				if(marker.marker_times.length > 0) txt = txt + " : " + marker.marker_times;
				txt = txt + "</td>";
			}			
			txt = txt + "</tr>";
			txt = txt + "</table>";			
		closeAllInfo();
		infowindow = new google.maps.InfoWindow({content: txt, disableAutoPan: false});
		infowindow.open(map, marker);

		map.panTo(marker.getPosition());

		google.maps.event.addListener(infowindow, 'closeclick', function () {
			map.panTo(dCenter);	
			map.setZoom(dZoom);
		});	
	});				
}
		
function aniMarker(marker_type){		
	closeAllInfo();
	mybounds = new google.maps.LatLngBounds();
	var cnt = 0;
	for(i=0;i < markerArray.length;i++){
		if(marker_type == 'all'){
			$('#legend_all').css('display','none');
			markerArray[i].setVisible(true);
			markerArray[i].setAnimation(google.maps.Animation.DROP);
			mybounds.extend(markerArray[i].getPosition());
			cnt++;
		} else {		
			markerArray[i].setVisible(false);		
			if(markerArray[i].marker_type == marker_type){
				$('#legend_all').css('display','');
				markerArray[i].setVisible(true);
				markerArray[i].setAnimation(google.maps.Animation.DROP);
				mybounds.extend(markerArray[i].getPosition());
				cnt++;
			}
		}
	}
	if(cnt == 0){
		for(i=0;i < markerArray.length;i++){
			mybounds.extend(markerArray[i].getPosition())
		}
		aniMarker('all');
		$('#errorhelper').text(marker_type);
		$("#no-markers-dialog").dialog({
			 modal: true,
			 buttons: {
//				Ok: function() {
//					 $( this ).dialog( "close" );
//				}
			 }
		});
		var timeout = setTimeout(function() {
			$("#no-markers-dialog").dialog( "close" );
		}, 5000);
		$("#no-markers-dialog").click(function(){
			 $(this).dialog( "close" );
			 clearTimeout(timeout);
		});
	}
	map.fitBounds(mybounds);
	map.panTo(mybounds.getCenter());
	dCenter = map.getCenter();
}
function closeAllInfo(){
	if (infowindow) infowindow.close();
}
// jquery stuff
$(document).ready(function(e) {
/*	$('#navSelect').change(function(e){
		term = $('#navSelect').find(":selected")[0].value;
		window.location = '/#' + term;
	});	*/
	$('#legend_today').click(function(){
		if(markerArray.length > 0) aniMarker('today');
	});	
	$('#legend_tomorrow').click(function(){
		if(markerArray.length > 0) aniMarker('tomorrow');
	});	
	$('#legend_upcoming').click(function(){
		if(markerArray.length > 0) aniMarker('upcoming');
	});	
	$('#legend_instore').click(function(){
		if(markerArray.length > 0) aniMarker('in store');
	});
	$('#legend_previous').click(function(){
		if(markerArray.length > 0) aniMarker('previous');
	});
	$('#legend_all').click(function(){
		if(markerArray.length > 0) aniMarker('all');
	});	
});
	